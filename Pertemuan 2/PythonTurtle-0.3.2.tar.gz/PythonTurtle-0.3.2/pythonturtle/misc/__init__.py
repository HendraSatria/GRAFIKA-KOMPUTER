"""
Supportive modules and classes for PythonTurtle implementation details.
"""
